import express from 'express';
import Progress from '../models/Progress.js';
import Course from '../models/Course.js';

const router = express.Router();

// Get progress for a student in a specific course
router.get('/:studentId/:courseId', async (req, res) => {
  try {
    const { studentId, courseId } = req.params;

    const progress = await Progress.findOne({ studentId, courseId });
    const course = await Course.findById(courseId);
    if (!course) return res.status(404).json({ message: "Course not found" });

    res.json({
      completedLessons: progress?.completedLessons || [],
      totalLessons: course.lessons.length
    });
  } catch (err) {
    res.status(500).json({ message: "Error getting progress", error: err.message });
  }
});

// Update progress (mark lesson complete)
router.post('/', async (req, res) => {
  try {
    const { studentId, courseId, lessonIndex } = req.body;

    let progress = await Progress.findOne({ studentId, courseId });
    if (!progress) {
      progress = new Progress({
        studentId,
        courseId,
        completedLessons: [lessonIndex]
      });
    } else {
      if (!progress.completedLessons.includes(lessonIndex)) {
        progress.completedLessons.push(lessonIndex);
      }
    }

    await progress.save();
    res.json({ message: "Progress updated successfully", completedLessons: progress.completedLessons });
  } catch (err) {
    res.status(500).json({ message: "Failed to update progress", error: err.message });
  }
});

export default router;
