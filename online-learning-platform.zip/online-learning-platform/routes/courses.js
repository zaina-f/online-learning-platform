import express from "express";
import Course from "../models/Course.js";

const router = express.Router();

//  Get all courses
router.get("/", async (req, res) => {
  try {
    const courses = await Course.find().populate("instructor", "name email");
    res.json(courses);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// get courses by instructor ID
router.get("/instructor/:instructorId", async (req, res) => {
  console.log(" instructor route hit with ID:", req.params.instructorId);
  try {
    const courses = await Course.find({ instructor: req.params.instructorId });
    console.log(" Found courses count:", courses.length);
    return res.json(courses);
  } catch (err) {
    console.error(" Instructor route error:", err);
    return res.status(500).json({ message: "Server error", error: err.message });
  }
});
//  Get a single course by ID
router.get("/:id", async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ message: "Course not found" });
    res.json(course);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

//  Create a course
router.post("/", async (req, res) => {
  const { title, description, instructor, lessons, liveSession } = req.body;

  try {
    const course = new Course({
      title,
      description,
      instructor,
      lessons,
      liveSession,
    });
    await course.save();
    res.status(201).json(course);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

export default router;
