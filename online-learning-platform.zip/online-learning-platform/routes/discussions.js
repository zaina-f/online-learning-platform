import express from 'express';
const router = express.Router();
import Discussion from '../models/Discussions.js';

//  Get all messages for a course
router.get('/:courseId', async (req, res) => {
  try {
    const messages = await Discussion.find({ course: req.params.courseId })
      .populate('student', 'name')
      .sort({ timestamp: 1 });
    res.json(messages);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch discussions' });
  }
});

//  Post a new message
router.post('/', async (req, res) => {
  try {
    const { courseId, studentId, message } = req.body;
    if (!message) return res.status(400).json({ message: 'Message cannot be empty' });

    const newMsg = new Discussion({ course: courseId, student: studentId, message });
    await newMsg.save();
    res.status(201).json({ message: 'Posted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to post message' });
  }
});

export default router;
