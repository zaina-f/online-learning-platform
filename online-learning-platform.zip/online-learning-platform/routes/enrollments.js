import express from 'express';
import Enrollment from '../models/Enrollment.js';

const router = express.Router();

//  Enroll in course
router.post('/', async (req, res) => {
  const { studentId, courseId } = req.body;
  try {
    const exists = await Enrollment.findOne({ studentId, courseId });
    if (exists) return res.json({ message: "Already enrolled" });

    const enrollment = new Enrollment({ studentId, courseId });
    await enrollment.save();
    res.status(201).json({ message: "Enrolled successfully", enrollment });
  } catch (err) {
    res.status(500).json({ message: "Error enrolling", error: err });
  }
});

//  Get enrolled courses of a student
router.get('/user/:userId', async (req, res) => {
  try {
    const enrollments = await Enrollment.find({ studentId: req.params.userId }).populate('courseId');
    const formatted = enrollments.map(enroll => ({
      course: enroll.courseId,
      enrolledAt: enroll.enrolledAt
    }));
    res.json(formatted);
  } catch (err) {
    res.status(500).json({ message: "Error loading enrollments", error: err });
  }
});
// Get all enrollments for a specific course
router.get('/course/:courseId', async (req, res) => {
  try {
    const enrollments = await Enrollment.find({ courseId: req.params.courseId });
    res.json(enrollments);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

export default router;

